// Basic interactivity: year, mobile menu, form validation + modal
document.addEventListener('DOMContentLoaded', function(){
  // set year
  const y = new Date().getFullYear();
  const yearEl = document.getElementById('year');
  if (yearEl) yearEl.textContent = y;

  // mobile menu
  const menuToggle = document.getElementById('menuToggle');
  const mainNav = document.getElementById('mainNav');
  if(menuToggle && mainNav){
    menuToggle.addEventListener('click', function(){
      if(mainNav.style.display === 'flex') mainNav.style.display = 'none';
      else mainNav.style.display = 'flex';
    });
  }
});

// Form handling
function handleSubmit(e){
  e.preventDefault();
  const form = document.getElementById('orderForm');
  const name = document.getElementById('name').value.trim();
  const email = document.getElementById('email').value.trim();
  const service = document.getElementById('service').value;
  // basic validation
  if(name.length < 2){ alert('Please enter a valid name'); return false; }
  if(!validateEmail(email)){ alert('Please enter a valid email'); return false; }
  if(service === ''){ alert('Please select a service'); return false; }

  // Show thank you modal
  openModal();
  // Reset form
  form.reset();

  // OPTIONAL: Send form data to an API (Formspree or server) - not included here
  return false;
}

function validateEmail(email){
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function openModal(){
  const modal = document.getElementById('thankModal');
  if(modal){ modal.style.display = 'flex'; }
}
function closeModal(){
  const modal = document.getElementById('thankModal');
  if(modal){ modal.style.display = 'none'; }
}